#ifndef INICIA_H_INCLUDED
#define INICIA_H_INCLUDED

void inicia_allegro(int ANCHO_ , int ALTO_);
int inicia_audio(int izquierda, int derecha);

#endif // INICIA_H_INCLUDED
