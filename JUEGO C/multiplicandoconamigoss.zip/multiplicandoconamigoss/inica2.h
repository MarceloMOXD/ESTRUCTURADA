#ifndef INICA2_H_INCLUDED
#define INICA2_H_INCLUDED

int audio(int dig, int stereo);
void allegro(int ANCHO_ , int ALTO_);

#endif // INICA2_H_INCLUDED
